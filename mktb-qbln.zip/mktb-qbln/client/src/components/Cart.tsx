import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Download, MessageCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CartItem {
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  unitPrice: string;
  subtotal: string;
}

interface CartProps {
  items: CartItem[];
  customerName: string;
  onRemoveItem: (index: number) => void;
  onSaveAndSend: () => void;
  onSavePDF: () => void;
}

export default function Cart({ items, customerName, onRemoveItem, onSaveAndSend, onSavePDF }: CartProps) {
  const totalAmount = items.reduce((sum, item) => sum + parseFloat(item.subtotal), 0);

  if (items.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>سلة المشتريات</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-8">
            السلة فارغة
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>سلة المشتريات</span>
          <span className="text-sm font-normal text-muted-foreground">{customerName}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-2">
            <div className="grid grid-cols-6 gap-2 pb-2 border-b text-sm font-semibold text-muted-foreground">
              <div className="col-span-2">المنتج</div>
              <div className="text-center">الكمية</div>
              <div className="text-center">الوحدة</div>
              <div className="text-center">السعر</div>
              <div className="text-center">الإجمالي</div>
            </div>

            {items.map((item, index) => (
              <div
                key={index}
                className="grid grid-cols-6 gap-2 py-3 border-b items-center"
                data-testid={`cart-item-${index}`}
              >
                <div className="col-span-2 font-medium" data-testid={`text-cart-product-${index}`}>
                  {item.productName}
                </div>
                <div className="text-center" data-testid={`text-cart-quantity-${index}`}>
                  {item.quantity}
                </div>
                <div className="text-center text-sm text-muted-foreground">
                  {item.unit}
                </div>
                <div className="text-center font-semibold">
                  {parseFloat(item.unitPrice).toFixed(2)}
                </div>
                <div className="text-center font-bold text-primary">
                  {parseFloat(item.subtotal).toFixed(2)}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => onRemoveItem(index)}
                  className="h-8 w-8"
                  data-testid={`button-remove-${index}`}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="mt-4 pt-4 border-t">
          <div className="flex justify-between items-center text-lg font-bold">
            <span>المجموع الكلي:</span>
            <span className="text-2xl text-primary" data-testid="text-total-amount">
              {totalAmount.toFixed(2)} د.ع
            </span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="flex gap-2 flex-wrap">
        <Button
          onClick={onSaveAndSend}
          className="flex-1 gap-2"
          data-testid="button-save-send-whatsapp"
        >
          <MessageCircle className="h-4 w-4" />
          حفظ وإرسال عبر واتساب
        </Button>
        <Button
          onClick={onSavePDF}
          variant="outline"
          className="flex-1 gap-2"
          data-testid="button-save-pdf"
        >
          <Download className="h-4 w-4" />
          حفظ PDF
        </Button>
      </CardFooter>
    </Card>
  );
}
