import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Category, Product } from "@shared/schema";
import { Upload } from "lucide-react";

interface ProductFormDialogProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: {
    name: string;
    categoryId: string;
    cartonPrice: string;
    packetPrice?: string;
    imageUrl?: string;
  }) => void;
  categories: Category[];
  product?: Product | null;
  mode: "add" | "edit";
}

export default function ProductFormDialog({
  open,
  onClose,
  onSave,
  categories,
  product,
  mode,
}: ProductFormDialogProps) {
  const [name, setName] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [cartonPrice, setCartonPrice] = useState("");
  const [packetPrice, setPacketPrice] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  useEffect(() => {
    if (product && mode === "edit") {
      setName(product.name);
      setCategoryId(product.categoryId);
      setCartonPrice(product.cartonPrice);
      setPacketPrice(product.packetPrice || "");
      setImageUrl(product.imageUrl || "");
    } else {
      setName("");
      setCategoryId("");
      setCartonPrice("");
      setPacketPrice("");
      setImageUrl("");
    }
  }, [product, mode, open]);

  const handleSubmit = () => {
    if (!name.trim() || !categoryId || !cartonPrice) {
      return;
    }

    onSave({
      name: name.trim(),
      categoryId,
      cartonPrice,
      packetPrice: packetPrice || undefined,
      imageUrl: imageUrl || undefined,
    });

    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{mode === "add" ? "إضافة منتج جديد" : "تعديل المنتج"}</DialogTitle>
          <DialogDescription className="sr-only">
            {mode === "add" ? "أدخل بيانات المنتج الجديد" : "عدل بيانات المنتج"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="product-name">اسم المنتج</Label>
            <Input
              id="product-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="أدخل اسم المنتج"
              className="text-right"
              data-testid="input-product-name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">القسم</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger id="category" data-testid="select-category">
                <SelectValue placeholder="اختر القسم" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="carton-price">سعر الكارتون (د.ع)</Label>
            <Input
              id="carton-price"
              type="number"
              step="0.01"
              value={cartonPrice}
              onChange={(e) => setCartonPrice(e.target.value)}
              placeholder="0.00"
              className="text-right"
              data-testid="input-carton-price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="packet-price">سعر الباكيت (د.ع) - اختياري للحلويات</Label>
            <Input
              id="packet-price"
              type="number"
              step="0.01"
              value={packetPrice}
              onChange={(e) => setPacketPrice(e.target.value)}
              placeholder="0.00"
              className="text-right"
              data-testid="input-packet-price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="image-url">رابط الصورة - اختياري</Label>
            <div className="flex gap-2">
              <Input
                id="image-url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="text-right"
                data-testid="input-image-url"
              />
              <Button variant="outline" size="icon" type="button">
                <Upload className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button onClick={handleSubmit} data-testid="button-save-product">
            {mode === "add" ? "إضافة" : "حفظ التعديلات"}
          </Button>
          <Button onClick={onClose} variant="outline" data-testid="button-cancel">
            إلغاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
