import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import type { Product } from "@shared/schema";
import { AlertTriangle } from "lucide-react";

interface DeleteProductDialogProps {
  open: boolean;
  onClose: () => void;
  onDelete: (productId: string) => void;
  products: Product[];
}

export default function DeleteProductDialog({
  open,
  onClose,
  onDelete,
  products,
}: DeleteProductDialogProps) {
  const [selectedProductId, setSelectedProductId] = useState("");

  const handleDelete = () => {
    if (!selectedProductId) return;
    onDelete(selectedProductId);
    setSelectedProductId("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            حذف منتج
          </DialogTitle>
          <DialogDescription className="sr-only">
            اختر المنتج المراد حذفه نهائياً
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="delete-product">اختر المنتج المراد حذفه</Label>
            <Select value={selectedProductId} onValueChange={setSelectedProductId}>
              <SelectTrigger id="delete-product" data-testid="select-delete-product">
                <SelectValue placeholder="اختر المنتج" />
              </SelectTrigger>
              <SelectContent>
                {products.map((product) => (
                  <SelectItem key={product.id} value={product.id}>
                    {product.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <p className="text-sm text-muted-foreground bg-destructive/10 p-3 rounded-md">
            تحذير: لا يمكن التراجع عن هذا الإجراء. سيتم حذف المنتج نهائياً.
          </p>
        </div>

        <DialogFooter className="gap-2">
          <Button
            onClick={handleDelete}
            variant="destructive"
            disabled={!selectedProductId}
            data-testid="button-confirm-delete"
          >
            حذف المنتج
          </Button>
          <Button onClick={onClose} variant="outline" data-testid="button-cancel-delete">
            إلغاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
