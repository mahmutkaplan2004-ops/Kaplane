import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Store, UserCog } from "lucide-react";

interface LoginDialogProps {
  open: boolean;
  onLoginSuccess: (type: "customer" | "representative", name: string) => void;
}

export default function LoginDialog({ open, onLoginSuccess }: LoginDialogProps) {
  const [loginType, setLoginType] = useState<"customer" | "representative" | null>(null);
  const [customerName, setCustomerName] = useState("");
  const [repName, setRepName] = useState("");
  const [repCode, setRepCode] = useState("");
  const [error, setError] = useState("");

  const handleCustomerLogin = () => {
    if (!customerName.trim()) {
      setError("الرجاء إدخال اسم الماركت");
      return;
    }
    onLoginSuccess("customer", customerName);
  };

  const handleRepresentativeLogin = () => {
    if (!repName.trim()) {
      setError("الرجاء إدخال اسم المندوب");
      return;
    }
    if (repCode !== "20040104") {
      setError("الرمز السري غير صحيح");
      return;
    }
    // Store rep code for API authentication
    localStorage.setItem("rep-code", repCode);
    onLoginSuccess("representative", repName);
  };

  const resetForm = () => {
    setLoginType(null);
    setCustomerName("");
    setRepName("");
    setRepCode("");
    setError("");
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold">
            مرحباً بك في مكتب القبلان
          </DialogTitle>
          <DialogDescription className="sr-only">
            اختر نوع الدخول: زبون أو مندوب
          </DialogDescription>
        </DialogHeader>

        {!loginType ? (
          <div className="grid gap-4 mt-4">
            <Button
              size="lg"
              variant="outline"
              className="h-24 flex-col gap-3 hover-elevate"
              onClick={() => setLoginType("customer")}
              data-testid="button-customer-option"
            >
              <Store className="h-8 w-8 text-primary" />
              <span className="text-lg font-semibold">زبون</span>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="h-24 flex-col gap-3 hover-elevate"
              onClick={() => setLoginType("representative")}
              data-testid="button-representative-option"
            >
              <UserCog className="h-8 w-8 text-primary" />
              <span className="text-lg font-semibold">مندوب</span>
            </Button>
          </div>
        ) : loginType === "customer" ? (
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="customer-name">اسم الماركت</Label>
              <Input
                id="customer-name"
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  setError("");
                }}
                placeholder="أدخل اسم الماركت"
                className="text-right"
                data-testid="input-customer-name"
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <div className="flex gap-2">
              <Button onClick={handleCustomerLogin} className="flex-1" data-testid="button-customer-login">
                دخول
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1" data-testid="button-back">
                رجوع
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="rep-name">اسم المندوب</Label>
              <Input
                id="rep-name"
                value={repName}
                onChange={(e) => {
                  setRepName(e.target.value);
                  setError("");
                }}
                placeholder="أدخل اسم المندوب"
                className="text-right"
                data-testid="input-representative-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rep-code">الرمز السري</Label>
              <Input
                id="rep-code"
                type="password"
                value={repCode}
                onChange={(e) => {
                  setRepCode(e.target.value);
                  setError("");
                }}
                placeholder="أدخل الرمز السري"
                className="text-right"
                data-testid="input-representative-code"
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <div className="flex gap-2">
              <Button onClick={handleRepresentativeLogin} className="flex-1" data-testid="button-representative-login">
                دخول
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1" data-testid="button-back-rep">
                رجوع
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
