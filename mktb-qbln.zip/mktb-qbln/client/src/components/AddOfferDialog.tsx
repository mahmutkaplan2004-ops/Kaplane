import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Product, Category } from "@shared/schema";
import { Tag } from "lucide-react";

interface AddOfferDialogProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: { productId: string; oldPrice: string; newPrice: string }) => void;
  products: Product[];
  categories: Category[];
}

export default function AddOfferDialog({
  open,
  onClose,
  onSave,
  products,
  categories,
}: AddOfferDialogProps) {
  const [categoryId, setCategoryId] = useState("");
  const [productId, setProductId] = useState("");
  const [oldPrice, setOldPrice] = useState("");
  const [newPrice, setNewPrice] = useState("");

  const filteredProducts = categoryId
    ? products.filter((p) => p.categoryId === categoryId)
    : products;

  const selectedProduct = products.find((p) => p.id === productId);

  const handleSubmit = () => {
    if (!productId || !oldPrice || !newPrice) return;

    onSave({
      productId,
      oldPrice,
      newPrice,
    });

    setCategoryId("");
    setProductId("");
    setOldPrice("");
    setNewPrice("");
    onClose();
  };

  const handleProductChange = (value: string) => {
    setProductId(value);
    const product = products.find((p) => p.id === value);
    if (product) {
      setOldPrice(product.cartonPrice);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="h-5 w-5 text-primary" />
            إضافة منتج للعروضات
          </DialogTitle>
          <DialogDescription className="sr-only">
            اختر المنتج وحدد السعر القديم والجديد للعرض
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="offer-category">اختر القسم</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger id="offer-category" data-testid="select-offer-category">
                <SelectValue placeholder="اختر القسم" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="offer-product">اختر المنتج</Label>
            <Select value={productId} onValueChange={handleProductChange} disabled={!categoryId}>
              <SelectTrigger id="offer-product" data-testid="select-offer-product">
                <SelectValue placeholder="اختر المنتج" />
              </SelectTrigger>
              <SelectContent>
                {filteredProducts.map((product) => (
                  <SelectItem key={product.id} value={product.id}>
                    {product.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="old-price">السعر القديم (د.ع)</Label>
            <Input
              id="old-price"
              type="number"
              step="0.01"
              value={oldPrice}
              onChange={(e) => setOldPrice(e.target.value)}
              placeholder="0.00"
              className="text-right"
              disabled
              data-testid="input-old-price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-price">السعر الجديد (د.ع)</Label>
            <Input
              id="new-price"
              type="number"
              step="0.01"
              value={newPrice}
              onChange={(e) => setNewPrice(e.target.value)}
              placeholder="0.00"
              className="text-right"
              data-testid="input-new-price"
            />
          </div>

          {selectedProduct && (
            <div className="bg-muted p-3 rounded-md text-sm">
              <p className="font-semibold">{selectedProduct.name}</p>
              <p className="text-muted-foreground mt-1">
                السعر الحالي: {parseFloat(selectedProduct.cartonPrice).toFixed(2)} د.ع
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button
            onClick={handleSubmit}
            disabled={!productId || !oldPrice || !newPrice}
            data-testid="button-save-offer"
          >
            إضافة للعروضات
          </Button>
          <Button onClick={onClose} variant="outline" data-testid="button-cancel-offer">
            إلغاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
