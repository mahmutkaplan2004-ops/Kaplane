import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { FileText, Package } from "lucide-react";
import type { Order, OrderItem } from "@shared/schema";

interface OrdersDialogProps {
  open: boolean;
  onClose: () => void;
}

type OrderWithItems = Order & { items: OrderItem[] };

export default function OrdersDialog({ open, onClose }: OrdersDialogProps) {
  const { data: orders = [], isLoading } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders"],
    enabled: open,
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            الطلبيات المحفوظة
          </DialogTitle>
          <DialogDescription className="sr-only">
            عرض جميع الطلبيات المحفوظة
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[60vh]">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">جاري التحميل...</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">لا توجد طلبيات محفوظة</div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <Card key={order.id} data-testid={`order-${order.id}`}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        <span>{order.customerName}</span>
                      </div>
                      <span className="text-primary font-bold">
                        {parseFloat(order.totalAmount).toFixed(2)} د.ع
                      </span>
                    </CardTitle>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(order.createdAt), "yyyy-MM-dd HH:mm")}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {order.items.map((item, index) => (
                        <div
                          key={index}
                          className="flex justify-between items-center text-sm border-b pb-2"
                        >
                          <div>
                            <p className="font-medium">{item.productName}</p>
                            <p className="text-xs text-muted-foreground">
                              {item.quantity} {item.unit} × {parseFloat(item.unitPrice).toFixed(2)} د.ع
                            </p>
                          </div>
                          <span className="font-semibold">
                            {parseFloat(item.subtotal).toFixed(2)} د.ع
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
