import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import {
  MoreVertical,
  Plus,
  Edit,
  Trash2,
  FileText,
  Power,
  PowerOff,
  Save,
  Tag,
} from "lucide-react";

interface AdminMenuProps {
  isActive: boolean;
  onAddProduct: () => void;
  onEditProduct: () => void;
  onDeleteProduct: () => void;
  onViewOrders: () => void;
  onToggleSite: () => void;
  onSaveData: () => void;
  onAddToOffers: () => void;
}

export default function AdminMenu({
  isActive,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onViewOrders,
  onToggleSite,
  onSaveData,
  onAddToOffers,
}: AdminMenuProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" data-testid="button-admin-menu">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem onClick={onAddProduct} data-testid="menu-add-product">
          <Plus className="ml-2 h-4 w-4" />
          إضافة منتج
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onEditProduct} data-testid="menu-edit-product">
          <Edit className="ml-2 h-4 w-4" />
          تعديل منتج
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onDeleteProduct} className="text-destructive" data-testid="menu-delete-product">
          <Trash2 className="ml-2 h-4 w-4" />
          حذف منتج
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onAddToOffers} data-testid="menu-add-offer">
          <Tag className="ml-2 h-4 w-4" />
          عرض منتج
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onViewOrders} data-testid="menu-view-orders">
          <FileText className="ml-2 h-4 w-4" />
          عرض الطلبيات
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onToggleSite} data-testid="menu-toggle-site">
          {isActive ? (
            <>
              <PowerOff className="ml-2 h-4 w-4 text-destructive" />
              <span className="text-destructive">إيقاف الموقع للزبائن</span>
            </>
          ) : (
            <>
              <Power className="ml-2 h-4 w-4 text-green-600" />
              <span className="text-green-600">تشغيل الموقع للزبائن</span>
            </>
          )}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onSaveData} data-testid="menu-save-data">
          <Save className="ml-2 h-4 w-4" />
          حفظ جميع البيانات
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
