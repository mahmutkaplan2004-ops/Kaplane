import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Minus, Plus, ShoppingCart, Package } from "lucide-react";
import type { Product, Offer } from "@shared/schema";

interface ProductCardProps {
  product: Product & { offer?: Offer | null };
  isSweets: boolean;
  onAddToCart: (item: {
    productId: string;
    productName: string;
    quantity: number;
    unit: string;
    unitPrice: string;
    subtotal: string;
  }) => void;
}

type UnitType = "كارتون" | "نصف كارتون" | "باكيت";

export default function ProductCard({ product, isSweets, onAddToCart }: ProductCardProps) {
  const [selectedUnit, setSelectedUnit] = useState<UnitType>("كارتون");
  const [quantity, setQuantity] = useState(1);

  const cartonPrice = product.offer ? parseFloat(product.offer.newPrice) : parseFloat(product.cartonPrice);
  const halfCartonPrice = cartonPrice / 2;
  const packetPrice = product.packetPrice ? parseFloat(product.packetPrice) : 0;

  const getCurrentUnitPrice = () => {
    if (selectedUnit === "كارتون") return cartonPrice;
    if (selectedUnit === "نصف كارتون") return halfCartonPrice;
    return packetPrice;
  };

  const handleAddToCart = () => {
    const unitPrice = getCurrentUnitPrice();
    const subtotal = unitPrice * quantity;
    
    onAddToCart({
      productId: product.id,
      productName: product.name,
      quantity,
      unit: selectedUnit,
      unitPrice: unitPrice.toFixed(2),
      subtotal: subtotal.toFixed(2),
    });
    
    setQuantity(1);
  };

  return (
    <Card className="overflow-hidden hover-elevate" data-testid={`card-product-${product.id}`}>
      <div className="flex gap-4 p-4">
        {/* Product Image */}
        <div className="flex-shrink-0">
          <div className="w-24 h-24 rounded-md bg-muted flex items-center justify-center overflow-hidden">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <Package className="h-12 w-12 text-muted-foreground" />
            )}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex-1 space-y-3">
          <div>
            <h3 className="font-semibold text-lg" data-testid={`text-product-name-${product.id}`}>
              {product.name}
            </h3>
            
            {/* Price Display */}
            <div className="mt-1">
              {product.offer ? (
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="destructive" className="text-xs">عرض خاص</Badge>
                  <span className="text-sm text-muted-foreground line-through">
                    {parseFloat(product.offer.oldPrice).toFixed(2)} د.ع
                  </span>
                  <span className="text-lg font-bold text-primary">
                    {parseFloat(product.offer.newPrice).toFixed(2)} د.ع
                  </span>
                </div>
              ) : (
                <span className="text-lg font-bold text-foreground">
                  {getCurrentUnitPrice().toFixed(2)} د.ع
                </span>
              )}
            </div>
          </div>

          {/* Unit Selector */}
          <div className="flex gap-2 flex-wrap">
            <Button
              size="sm"
              variant={selectedUnit === "كارتون" ? "default" : "outline"}
              onClick={() => setSelectedUnit("كارتون")}
              className="text-sm"
              data-testid={`button-unit-carton-${product.id}`}
            >
              كارتون
            </Button>
            <Button
              size="sm"
              variant={selectedUnit === "نصف كارتون" ? "default" : "outline"}
              onClick={() => setSelectedUnit("نصف كارتون")}
              className="text-sm"
              data-testid={`button-unit-half-${product.id}`}
            >
              نصف كارتون
            </Button>
            {isSweets && packetPrice > 0 && (
              <Button
                size="sm"
                variant={selectedUnit === "باكيت" ? "default" : "outline"}
                onClick={() => setSelectedUnit("باكيت")}
                className="text-sm"
                data-testid={`button-unit-packet-${product.id}`}
              >
                باكيت
              </Button>
            )}
          </div>

          {/* Quantity Controls */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Button
                size="icon"
                variant="outline"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                className="h-8 w-8"
                data-testid={`button-decrease-${product.id}`}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center font-semibold" data-testid={`text-quantity-${product.id}`}>
                {quantity}
              </span>
              <Button
                size="icon"
                variant="outline"
                onClick={() => setQuantity(quantity + 1)}
                className="h-8 w-8"
                data-testid={`button-increase-${product.id}`}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <Button onClick={handleAddToCart} size="sm" className="gap-2" data-testid={`button-add-cart-${product.id}`}>
              <ShoppingCart className="h-4 w-4" />
              اطلب المنتج
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
