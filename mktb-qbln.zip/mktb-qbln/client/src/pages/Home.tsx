import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import LoginDialog from "@/components/LoginDialog";
import ProductCard from "@/components/ProductCard";
import Cart from "@/components/Cart";
import AdminMenu from "@/components/AdminMenu";
import ProductFormDialog from "@/components/ProductFormDialog";
import DeleteProductDialog from "@/components/DeleteProductDialog";
import AddOfferDialog from "@/components/AddOfferDialog";
import OrdersDialog from "@/components/OrdersDialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Category, Product, Offer } from "@shared/schema";
import { Package, PowerOff, Loader2 } from "lucide-react";

interface CartItem {
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  unitPrice: string;
  subtotal: string;
}

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState<"customer" | "representative">("customer");
  const [userName, setUserName] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  
  const [showProductForm, setShowProductForm] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showOfferDialog, setShowOfferDialog] = useState(false);
  const [showOrdersDialog, setShowOrdersDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formMode, setFormMode] = useState<"add" | "edit">("add");

  const { toast } = useToast();

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Fetch products
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Fetch offers
  const { data: offers = [] } = useQuery<Offer[]>({
    queryKey: ["/api/offers"],
  });

  // Fetch site settings
  const { data: siteSettings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const isActive = siteSettings?.isActive ?? true;

  const handleLogin = (type: "customer" | "representative", name: string) => {
    setUserType(type);
    setUserName(name);
    setIsLoggedIn(true);
  };

  const handleAddToCart = (item: CartItem) => {
    setCartItems([...cartItems, item]);
    toast({
      title: "تمت الإضافة",
      description: `تم إضافة ${item.productName} إلى السلة`,
    });
  };

  const handleRemoveItem = (index: number) => {
    setCartItems(cartItems.filter((_, i) => i !== index));
  };

  const handleSaveAndSend = async () => {
    if (cartItems.length === 0) return;

    const totalAmount = cartItems.reduce((sum, item) => sum + parseFloat(item.subtotal), 0);
    
    const orderData = {
      customerName: userName,
      totalAmount: totalAmount.toFixed(2),
      items: cartItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        unit: item.unit,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
      })),
    };

    createOrderMutation.mutate(orderData, {
      onSuccess: () => {
        // Generate WhatsApp message
        let message = `*طلبية جديدة من ${userName}*\n\n`;
        cartItems.forEach((item, index) => {
          message += `${index + 1}. ${item.productName}\n`;
          message += `   الكمية: ${item.quantity} ${item.unit}\n`;
          message += `   السعر: ${parseFloat(item.subtotal).toFixed(2)} د.ع\n\n`;
        });
        message += `*المجموع الكلي: ${totalAmount.toFixed(2)} د.ع*`;

        const whatsappUrl = `https://wa.me/9647706831028?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, "_blank");

        toast({
          title: "تم الحفظ",
          description: "تم حفظ الطلبية وفتح واتساب",
        });
      },
    });
  };

  const handleSavePDF = async () => {
    if (cartItems.length === 0) return;

    const totalAmount = cartItems.reduce((sum, item) => sum + parseFloat(item.subtotal), 0);
    
    const orderData = {
      customerName: userName,
      totalAmount: totalAmount.toFixed(2),
      items: cartItems.map(item => ({
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        unit: item.unit,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
      })),
    };

    createOrderMutation.mutate(orderData, {
      onSuccess: async () => {
        // Generate PDF using jsPDF
        const { jsPDF } = await import('jspdf');
        const doc = new jsPDF();

        // Add Arabic support (right-to-left)
        doc.setR2L(true);

        // Add title
        doc.setFontSize(20);
        doc.text("مكتب القبلان", 105, 20, { align: "center" });

        // Add customer name
        doc.setFontSize(14);
        doc.text(`الزبون: ${userName}`, 190, 35, { align: "right" });

        // Add table headers
        doc.setFontSize(12);
        let y = 50;
        doc.text("المنتج", 150, y, { align: "right" });
        doc.text("الكمية", 110, y, { align: "right" });
        doc.text("الوحدة", 80, y, { align: "right" });
        doc.text("السعر", 50, y, { align: "right" });
        doc.text("الإجمالي", 20, y, { align: "right" });

        // Add line
        doc.line(10, y + 2, 200, y + 2);

        // Add items
        y += 10;
        cartItems.forEach((item) => {
          doc.setFontSize(10);
          doc.text(item.productName, 150, y, { align: "right" });
          doc.text(item.quantity.toString(), 110, y, { align: "right" });
          doc.text(item.unit, 80, y, { align: "right" });
          doc.text(`${parseFloat(item.unitPrice).toFixed(2)} د.ع`, 50, y, { align: "right" });
          doc.text(`${parseFloat(item.subtotal).toFixed(2)} د.ع`, 20, y, { align: "right" });
          y += 8;
        });

        // Add line
        doc.line(10, y, 200, y);
        y += 10;

        // Add total
        doc.setFontSize(14);
        doc.text(`المجموع الكلي: ${totalAmount.toFixed(2)} د.ع`, 190, y, { align: "right" });

        // Add date
        doc.setFontSize(10);
        doc.text(`التاريخ: ${new Date().toLocaleDateString('ar-IQ')}`, 190, y + 15, { align: "right" });

        // Save PDF
        doc.save(`order-${userName}-${Date.now()}.pdf`);

        toast({
          title: "تم الحفظ",
          description: "تم حفظ الطلبية وتحميل ملف PDF",
        });
      },
    });
  };

  const handleAddProduct = () => {
    setFormMode("add");
    setEditingProduct(null);
    setShowProductForm(true);
  };

  const handleEditProduct = () => {
    setFormMode("edit");
    setShowProductForm(true);
  };

  // Mutations
  const createProductMutation = useMutation({
    mutationFn: async (data: any) => await apiRequest("POST", "/api/products", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة المنتج بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية الإضافة",
        variant: "destructive",
      });
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) =>
      await apiRequest("PATCH", `/api/products/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "تم التحديث",
        description: "تم تحديث المنتج بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية التحديث",
        variant: "destructive",
      });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: string) => await apiRequest("DELETE", `/api/products/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/offers"] });
      toast({
        title: "تم الحذف",
        description: "تم حذف المنتج بنجاح",
        variant: "destructive",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية الحذف",
        variant: "destructive",
      });
    },
  });

  const createOfferMutation = useMutation({
    mutationFn: async (data: any) => await apiRequest("POST", "/api/offers", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/offers"] });
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة المنتج للعروضات بنجاح",
      });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية الإضافة",
        variant: "destructive",
      });
    },
  });

  const toggleSiteMutation = useMutation({
    mutationFn: async (isActive: boolean) =>
      await apiRequest("PATCH", "/api/settings", { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية التحديث",
        variant: "destructive",
      });
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: any) => await apiRequest("POST", "/api/orders", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setCartItems([]);
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشلت عملية حفظ الطلبية",
        variant: "destructive",
      });
    },
  });

  const handleSaveProduct = (data: any) => {
    if (formMode === "add") {
      createProductMutation.mutate(data);
    } else if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data });
    }
  };

  const handleDeleteProduct = (productId: string) => {
    deleteProductMutation.mutate(productId);
  };

  const handleAddOffer = (data: any) => {
    createOfferMutation.mutate(data);
  };

  const handleToggleSite = () => {
    const newStatus = !isActive;
    toggleSiteMutation.mutate(newStatus);
    toast({
      title: newStatus ? "تم التشغيل" : "تم الإيقاف",
      description: newStatus ? "تم تشغيل الموقع للزبائن" : "تم إيقاف الموقع للزبائن",
    });
  };

  const handleSaveData = () => {
    toast({
      title: "تم الحفظ",
      description: "تم حفظ جميع البيانات بنجاح",
    });
  };

  const handleViewOrders = () => {
    setShowOrdersDialog(true);
  };

  // Filter products by category
  const filteredProducts = selectedCategory
    ? products.filter((p) => p.categoryId === selectedCategory)
    : [];

  // Add offers to products
  const productsWithOffers = filteredProducts.map((product) => ({
    ...product,
    offer: offers.find((offer) => offer.productId === product.id) || null,
  }));

  // Check if customer and site is inactive
  if (isLoggedIn && userType === "customer" && !isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="p-8 text-center max-w-md">
          <PowerOff className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">الموقع متوقف مؤقتاً</h2>
          <p className="text-muted-foreground">
            عذراً، الموقع متوقف حالياً. يرجى المحاولة لاحقاً.
          </p>
        </Card>
      </div>
    );
  }

  if (!isLoggedIn) {
    return <LoginDialog open={true} onLoginSuccess={handleLogin} />;
  }

  const offersCategory = categories.find((cat) => cat.name === "العروضات");
  const offeredProducts = offersCategory
    ? products
        .filter((p) => offers.some((offer) => offer.productId === p.id))
        .map((product) => ({
          ...product,
          categoryId: offersCategory.id,
          offer: offers.find((offer) => offer.productId === product.id) || null,
        }))
    : [];

  const displayProducts = selectedCategory === offersCategory?.id
    ? offeredProducts
    : productsWithOffers;

  const selectedCategoryData = categories.find((c) => c.id === selectedCategory);
  const isSweets = selectedCategoryData?.name === "الحلويات";

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Package className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">مكتب القبلان</h1>
                <p className="text-sm text-muted-foreground">{userName}</p>
              </div>
            </div>

            {userType === "representative" && (
              <AdminMenu
                isActive={isActive}
                onAddProduct={handleAddProduct}
                onEditProduct={handleEditProduct}
                onDeleteProduct={() => setShowDeleteDialog(true)}
                onViewOrders={handleViewOrders}
                onToggleSite={handleToggleSite}
                onSaveData={handleSaveData}
                onAddToOffers={() => setShowOfferDialog(true)}
              />
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Categories */}
            {!selectedCategory && (
              <div>
                <h2 className="text-xl font-bold mb-4">الأقسام</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {categories.map((category) => (
                    <Button
                      key={category.id}
                      variant="outline"
                      className="h-20 flex-col gap-2 hover-elevate"
                      onClick={() => setSelectedCategory(category.id)}
                      data-testid={`button-category-${category.id}`}
                    >
                      <span className="text-lg font-semibold">{category.name}</span>
                      <Badge variant="secondary" className="text-xs">
                        {products.filter((p) => p.categoryId === category.id).length} منتج
                      </Badge>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Products */}
            {selectedCategory && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">
                    {selectedCategoryData?.name || "المنتجات"}
                  </h2>
                  <Button
                    variant="outline"
                    onClick={() => setSelectedCategory(null)}
                    data-testid="button-back-categories"
                  >
                    رجوع للأقسام
                  </Button>
                </div>

                <ScrollArea className="h-[600px]">
                  <div className="space-y-3">
                    {displayProducts.length === 0 ? (
                      <Card className="p-8 text-center">
                        <p className="text-muted-foreground">لا توجد منتجات في هذا القسم</p>
                      </Card>
                    ) : (
                      displayProducts.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          isSweets={isSweets}
                          onAddToCart={handleAddToCart}
                        />
                      ))
                    )}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>

          {/* Cart Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Cart
                items={cartItems}
                customerName={userName}
                onRemoveItem={handleRemoveItem}
                onSaveAndSend={handleSaveAndSend}
                onSavePDF={handleSavePDF}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <ProductFormDialog
        open={showProductForm}
        onClose={() => setShowProductForm(false)}
        onSave={handleSaveProduct}
        categories={categories.filter((c) => c.name !== "العروضات")}
        product={editingProduct}
        mode={formMode}
      />

      <DeleteProductDialog
        open={showDeleteDialog}
        onClose={() => setShowDeleteDialog(false)}
        onDelete={handleDeleteProduct}
        products={products}
      />

      <AddOfferDialog
        open={showOfferDialog}
        onClose={() => setShowOfferDialog(false)}
        onSave={handleAddOffer}
        products={products}
        categories={categories.filter((c) => c.name !== "العروضات")}
      />

      <OrdersDialog
        open={showOrdersDialog}
        onClose={() => setShowOrdersDialog(false)}
      />
    </div>
  );
}
