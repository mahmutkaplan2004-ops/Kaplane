import type { Request, Response, NextFunction } from "express";

const REPRESENTATIVE_CODE = "20040104";

export function requireRepresentative(req: Request, res: Response, next: NextFunction) {
  const authCode = req.headers["x-rep-code"];
  
  if (authCode !== REPRESENTATIVE_CODE) {
    return res.status(403).json({ error: "Unauthorized - Representative access required" });
  }
  
  next();
}
