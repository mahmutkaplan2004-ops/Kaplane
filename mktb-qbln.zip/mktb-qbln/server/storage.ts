// Reference: javascript_database blueprint
import { db } from "./db";
import { eq } from "drizzle-orm";
import {
  categories,
  products,
  offers,
  orders,
  orderItems,
  siteSettings,
  type Category,
  type InsertCategory,
  type Product,
  type InsertProduct,
  type Offer,
  type InsertOffer,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type SiteSettings,
} from "@shared/schema";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<void>;

  // Offers
  getOffers(): Promise<Offer[]>;
  getOfferByProductId(productId: string): Promise<Offer | undefined>;
  createOffer(offer: InsertOffer): Promise<Offer>;
  deleteOffer(id: string): Promise<void>;

  // Orders
  getOrders(): Promise<(Order & { items: OrderItem[] })[]>;
  getOrder(id: string): Promise<(Order & { items: OrderItem[] }) | undefined>;
  createOrder(order: InsertOrder, items: Omit<InsertOrderItem, "orderId">[]): Promise<Order & { items: OrderItem[] }>;

  // Site Settings
  getSiteSettings(): Promise<SiteSettings>;
  updateSiteSettings(isActive: boolean): Promise<SiteSettings>;
}

export class DatabaseStorage implements IStorage {
  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.order);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteProduct(id: string): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Offers
  async getOffers(): Promise<Offer[]> {
    return await db.select().from(offers);
  }

  async getOfferByProductId(productId: string): Promise<Offer | undefined> {
    const [offer] = await db.select().from(offers).where(eq(offers.productId, productId));
    return offer || undefined;
  }

  async createOffer(offer: InsertOffer): Promise<Offer> {
    // First, check if offer already exists for this product
    const existing = await this.getOfferByProductId(offer.productId);
    if (existing) {
      // Update existing offer
      const [updated] = await db
        .update(offers)
        .set({ oldPrice: offer.oldPrice, newPrice: offer.newPrice })
        .where(eq(offers.id, existing.id))
        .returning();
      return updated;
    }
    
    const [newOffer] = await db.insert(offers).values(offer).returning();
    return newOffer;
  }

  async deleteOffer(id: string): Promise<void> {
    await db.delete(offers).where(eq(offers.id, id));
  }

  // Orders
  async getOrders(): Promise<(Order & { items: OrderItem[] })[]> {
    const allOrders = await db.select().from(orders).orderBy(orders.createdAt);
    const ordersWithItems = await Promise.all(
      allOrders.map(async (order) => {
        const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
        return { ...order, items };
      })
    );
    return ordersWithItems;
  }

  async getOrder(id: string): Promise<(Order & { items: OrderItem[] }) | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
    return { ...order, items };
  }

  async createOrder(
    order: InsertOrder,
    items: Omit<InsertOrderItem, "orderId">[]
  ): Promise<Order & { items: OrderItem[] }> {
    const [newOrder] = await db.insert(orders).values(order).returning();

    const orderItemsWithOrderId = items.map((item) => ({
      ...item,
      orderId: newOrder.id,
    }));

    const newItems = await db.insert(orderItems).values(orderItemsWithOrderId).returning();

    return { ...newOrder, items: newItems };
  }

  // Site Settings
  async getSiteSettings(): Promise<SiteSettings> {
    const [settings] = await db.select().from(siteSettings).limit(1);
    
    if (!settings) {
      // Create default settings if none exist
      const [newSettings] = await db
        .insert(siteSettings)
        .values({ isActive: true })
        .returning();
      return newSettings;
    }
    
    return settings;
  }

  async updateSiteSettings(isActive: boolean): Promise<SiteSettings> {
    const settings = await this.getSiteSettings();
    const [updated] = await db
      .update(siteSettings)
      .set({ isActive })
      .where(eq(siteSettings.id, settings.id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
